package Characters;

import Model.GameManager;
import Model.Level;
import Model.MainApp;
import SideClasses.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Protagonist extends Sprite{
    //********** attributes ***********
    //-------- animation speed
    final int TARGET_FPS = 12;
    private double ANIMATION_TICKTIME = 1000000000 / TARGET_FPS;
    private double JUMP_FRAME = 1000000000 / 60;
    private double accumulatedTime = 0;
    private double lastTime = System.nanoTime();
    
    //------- initialise frame size of animations
    private int MOVERIGHT_SIZE = 3;
    private int MOVELEFT_SIZE = 5;
    private int JUMP_SIZE = 5;
    private int ATTACK_SIZE = 5;
    private double ATTACK_COOLDOWN = 1000000000 / 2;
    private int AMMO_SIZE = 10;
    //---- animations
    private BufferedImage[] Standby;
    private BufferedImage[] moveRight, moveLeft;
    private BufferedImage[] Jump;
    private BufferedImage[] Attack;
    private int frameCounter = 0;
    private JumpThread jumpThread;
    
    //----- 
    private double currentCooldown = 0;
    private char direction = 'r';
    private boolean IsAtGround = false;
    private int lastPositionY = 0;
    //----- properties
    private int Health;
    private int movementSpeed;
    private Ammo[] ammoAttack;
    private int ammoCounter = 0;
    //------ sounds
    private final Mp3 MovingMp3 = new Mp3("moving", "src/Effetti Sonori/passi_scarpe_cuoio_su_legno.wav");
    private final Mp3 JumpMp3 = new Mp3("jump","src/Effetti Sonori/sparo.wav");
    
    //********** constructor ************
    public Protagonist(int posx, int posy, int width, int height, String tag, boolean solidity, boolean gravity, int health){
        super(posx, posy, width, height, tag,solidity,gravity);
        //----- initialise attributes
        moveRight = new BufferedImage[MOVERIGHT_SIZE];
        moveLeft = new BufferedImage[MOVELEFT_SIZE];
        Jump = new BufferedImage[JUMP_SIZE];
        Attack = new BufferedImage[ATTACK_SIZE];
        ammoAttack = new Ammo[AMMO_SIZE];
        loadFrames();//load animation frames
        //----- initialise properties
        setHealth(health);
        currentFrame = moveRight[0];
        movementSpeed = 6;
        jumpThread = new JumpThread(this);
        //---- ammo
        for (int i = 0; i < AMMO_SIZE; i++ ){
            ammoAttack[i] = null;
        }
    }
    
    public void validate(){
    }
    //********** setting/getting ***********
    public Ammo[] getAmmoAttacks(){return this.ammoAttack;}
    public void removeAmmo(int aid){ammoAttack[aid] = null;}
    public void setHealth(int h){this.Health = h;}
    public boolean IsAtGround(){return this.IsAtGround;}
    public int getAmmoCounter(){return this.ammoCounter;}
    public void setAmmoCounter(int a){this.ammoCounter = a;}
    public void setGround(boolean g){this.IsAtGround = g;}
    //********** operators *********
    private final void loadFrames(){
        //!!!non avendo ancora le animazioni, questa parte lo facciamo dopo!!!
        try{
             for (int i = 0; i < moveRight.length; i++){
                moveRight[i] = ImageIO.read(getClass().getResource("../Graphics/Images/Protagonist/moveRight/" + Integer.toString(i) + ".png"));
             }  
        }catch(IOException ex){}
    }
    //********** operators ***********
    public void refreshFrame(){frameCounter = 0;}
    
    @Override
    public void Update(){
        super.Update();
        double now = System.nanoTime();
        double updateLength = now - lastTime;
        lastTime = now;
        // update the frame counter
        currentCooldown += updateLength;
        accumulatedTime += updateLength;
        doGravity();
        checkCollision();
    }
    public void moveRight(){
        if (frameCounter >= moveRight.length) frameCounter = 0;
        //----- when change action, reset frame count
        if (!currentAction.contains("moveRight")){
            frameCounter = 0;
            currentAction.add("moveRight");  
        }//--------- do it only if animation frame time is satisfied.
        if (accumulatedTime >= ANIMATION_TICKTIME && !currentAction.contains("jumping")) {
            direction = 'R';
            currentFrame = moveRight[frameCounter];
            PosX += movementSpeed;
            frameCounter++;
            accumulatedTime = 0;
//            MovingMp3.start();
        }
    }
    public void moveLeft(){
        if (frameCounter >= moveLeft.length) frameCounter = 0;
        //----- when change action, reset frame count
        if (!currentAction.contains("moveLeft")){
            frameCounter = 0;
            currentAction.add("moveLeft");
        }//--------- do it only if animation frame time is satisfied.
        if (accumulatedTime > ANIMATION_TICKTIME && !currentAction.contains("jumping")){
            direction = 'L';
            currentFrame = moveLeft[frameCounter];
            PosX -= movementSpeed;
            frameCounter++;
            accumulatedTime = 0;
//            MovingMp3.start();
        }
    }
    public void Jump(){
        if (!currentAction.contains("jumping") && !jumpThread.isAlive() && IsAtGround){
            currentAction.add("jumping");
//            JumpMp3.start();
            jumpThread.start();
        }
    }
    public void Attack(){
        //------ do attack only if cooldown has satisfied
        if (currentCooldown >= ATTACK_COOLDOWN){
            currentAction.clear();
            currentCooldown = 0;
            frameCounter = 0;
            //---- find the "null ammo" and make it a solid new ammo
            for (int i = 0; i < AMMO_SIZE; i++){
                if (ammoAttack[i] == null) {
                    ammoAttack[i] = new Ammo(PosX,PosY,direction,i);
                    i = AMMO_SIZE;
                }
            }
        }
    }

    private void doGravity(){
        boolean collided = false;
        if (Gravity){
            PosY += 3;
            for(int i = 0; i < Level.TILE_SIZE; i++){
                if (getBottomBound().intersects(Level.tiles[i].getBound())) {
                    //set protagonist's position Y up at tiles's top bound
                    PosY = Level.tiles[i].getPositionY() - Height;
                    collided = true;
                }
            }
        }
        IsAtGround = collided;
    }
    
    private void checkCollision(){
        if (IsSolid){
            for (int i = 0; i < Level.TILE_SIZE; i++){
                if (getRightBound().intersects(Level.tiles[i].getBound())){
                    //difference between right bound's position and tiles' left bound's position
                    PosX -= (Math.abs(PosX + Width - Level.tiles[i].getPositionX()));
                    if (Level.tiles[i].getTag().equals("exit")) {
                        MainApp.gameManager.setInGame(false);
                        MainApp.gameManager.loadScene(MainApp.gameManager.getCurrentScene() + 1);
                        MainApp.gameManager.setInGame(true);
                    }
                }
                if (getLeftBound().intersects(Level.tiles[i].getBound())){
                     //difference between left bound's position and tiles' right bound's position
                    PosX += (Math.abs(Level.tiles[i].getPositionX() + Level.tiles[i].getWidth() - PosX));
                }
            }
        }
    }
}
