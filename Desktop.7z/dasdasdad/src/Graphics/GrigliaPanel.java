/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphics;

import Controls.ActionControl;
import Model.Level;
import Model.MainApp;
import SideClasses.Ammo;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

/**
 *
 * @author t.erra
 */
public class GrigliaPanel extends JPanel {
    
    public static ActionControl actionController = new ActionControl();
    //grandezza cella
    private int Height=512;
    private int Width=1024;
    private Graphics2D g2d;
    public GrigliaPanel () {
        this.setPreferredSize(new Dimension(Width, Height));
        this.setBackground(Color.DARK_GRAY);
        this.setDoubleBuffered(true);
        this.addKeyListener(actionController);
        this.requestFocus();
    }
    
    public void paintComponent(Graphics g) {
            super.paintComponent(g);
            //lo casto in un oggetto Graphics2D in modo da poter usare l'antialiasing
            g2d = (Graphics2D)g;
            //uso l'antialiasing per disegnare linee e immagini maggiormente definite
            //posso farlo xke uso un oggetto Graphics2D
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (MainApp.gameManager.InGame()) render(g2d);
            g2d.dispose();
            g.dispose();
            this.requestFocus();
    }
    
    private final void render(Graphics2D g2){
            //---- disegno background
            g2.drawImage(Level.backgroundImage, 0, 0, Width, Height, null);
            //disegno una griglia di celle giusto per dare un'idea del mondo in cui si muove il personaggio
            //------- disegno personaggio
            g2.setColor(Color.red);
            g2.fillRect(Level.protagonist.getPositionX(), Level.protagonist.getPositionY(), Level.protagonist.getWidth(), Level.protagonist.getHeight());
            g2.drawImage(Level.protagonist.getCurrentFrame(), Level.protagonist.getPositionX(),Level.protagonist.getPositionY(), 50,70, this);
            g2.drawImage(Level.mob1.getCurrentFrame(), Level.mob1.getPositionX(),Level.mob1.getPositionY(), 32,32, this);
            //---------------! disegno le mattonelle !----------------
            for (int i = 0; i < Level.TILE_SIZE; i++){
                g2.drawImage(Level.tiles[i].getCurrentFrame(),Level.tiles[i].getPositionX(), Level.tiles[i].getPositionY(),null);
            }
        //-------------! disegno gli attacchi !-----
        for (Ammo ammo : Level.protagonist.getAmmoAttacks()){
            if (ammo != null) g2.drawImage(ammo.getCurrentFrame(),ammo.getPositionX(), ammo.getPositionY(),this);
        }
    }
    
    public int getWidth(){return this.Width;}
    public int getHeight(){return this.Height;}
    public Graphics2D getGraphics2D(){return g2d;}
    
    public void draw(BufferedImage frame, int posx, int posy, Component observer){
        g2d.drawImage(frame, posx,posy, observer);
    }
    
}
