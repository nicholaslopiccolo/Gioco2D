/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SideClasses;

import Characters.Mob;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author x.ruan
 */
public class AI extends Thread{
    Timer timer = new Timer();
    Mob mob;
    //******** constructor *********
    public AI(Mob mob){
        this.mob = mob;
        

    }
    @Override
    public void run(){
        timer.scheduleAtFixedRate(new TimerTask() {
        @Override
        public void run() {
           int i = 0;
           while(i < 10){
             mob.moveRight();
           }
        }
        }, 1, 1);
    }
}
