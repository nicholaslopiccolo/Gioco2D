/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gioco2d;


import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author thoma
 */
public class Main {
    
    
        public static JFrame main = new JFrame("Menu");
        public static SceltaPanel scelta = new SceltaPanel();
        public static OpzioniPanel opzioni = new OpzioniPanel();
        public static GrigliaPanel griglia = new GrigliaPanel();
    
    public static void main(String[] args) {
       
        BufferedImage img = null;
        try {
            img = ImageIO.read(new File("C:\\Users\\thoma\\Pictures\\erra\\Senza titolo-1.png"));
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        JLabel sfondo = new JLabel(new ImageIcon(img));
        
        sfondo.setLayout(new GridBagLayout());
        scelta.setLayout(new GridLayout(3,1,50,100));
        opzioni.setLayout(new GridLayout(3,1,50,100));
        
        GridBagConstraints gbc = new GridBagConstraints();
        
                    
                    
        gbc.gridwidth = GridBagConstraints.NORTH;
        gbc.fill = GridBagConstraints.CENTER;
        
        main.add(sfondo);
        sfondo.add(scelta);
        
        scelta.setVisible(true);
       
        main.setContentPane(sfondo);
        
        main.setVisible(true);
        main.pack();
        main.setLocationRelativeTo(null);
        main.setSize(1366 ,770);
        main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
}
