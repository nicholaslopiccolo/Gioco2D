/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gioco2d;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author t.erra
 */
public class OpzioniPanel extends JPanel{
    
    
    Icon blueB = new ImageIcon("C:\\Users\\thoma\\Pictures\\erra\\blue_button00.png");
    Icon greenB = new ImageIcon("C:\\Users\\thoma\\Pictures\\erra\\green_button00.png");
    Icon orangeB = new ImageIcon("C:\\Users\\thoma\\Pictures\\erra\\red_button01.png");
    
    Dimension d = new Dimension(190,49);
    Dimension s = new Dimension(480,450);
    
    JButton audioButton;
    JButton indietro;
    JButton salvaPartita;
    
    public OpzioniPanel() {
        
        this.audioButton = new JButton(blueB); 
        this.salvaPartita = new JButton(greenB);
        this.indietro = new JButton(orangeB);
      
        this.add(audioButton);
        this.add(salvaPartita);
        this.add(indietro);
      
        audioButton.setPreferredSize(d);
        salvaPartita.setPreferredSize(d);
        indietro.setPreferredSize(d);
    
        this.setBackground(Color.BLACK);
        this.setPreferredSize(s);
      
      indietro.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                indietroActionPerformed();
            }
        });
    }
    
    public void indietroActionPerformed(){
        if (Main.opzioni.isVisible()) {
            
            Main.main.remove(Main.opzioni);
            Main.main.add(Main.scelta);
            
            //validate e repaint servono per ridisegnare il contenuto del
            //frame
            Main.main.validate();
            Main.main.repaint();
            Main.scelta.setVisible(true);
            Main.opzioni.setVisible(false);
        }
    }   
}
