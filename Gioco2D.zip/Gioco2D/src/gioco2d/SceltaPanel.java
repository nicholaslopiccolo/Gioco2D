/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gioco2d;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 *
 * @author t.erra
 */
public class SceltaPanel extends JPanel implements MouseListener {
    
    Icon blueB = new ImageIcon("C:\\Users\\thoma\\Pictures\\erra\\blue_button00.png");
    Icon greenB = new ImageIcon("C:\\Users\\thoma\\Pictures\\erra\\green_button00.png");
    Icon yellowB = new ImageIcon("C:\\Users\\thoma\\Pictures\\erra\\yellow_button00.png");
    Dimension d = new Dimension(190,49);
    Dimension s = new Dimension(480,450);
    JButton nuovaPartita;
    JButton caricaPartita;
    JButton opzioni;
    
    
    
    
    public SceltaPanel()  {
        
    this.nuovaPartita = new JButton (blueB);
    this.caricaPartita = new JButton (greenB);
    this.opzioni = new JButton (yellowB);
    
    this.add(nuovaPartita);
    this.add(caricaPartita);
    this.add(opzioni);
    
    nuovaPartita.setPreferredSize(d);
    caricaPartita.setPreferredSize(d);
    opzioni.setPreferredSize(d);
    
    this.setBackground(Color.BLACK);
    this.setPreferredSize(s);
    
    
    opzioni.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
               opzioniActionPerformed();
            }
        });
    
    nuovaPartita.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
               nuovaPartitaActionPerformed();
            }
        });
    
    
    
}
    
    public void opzioniActionPerformed(){
        if (Main.scelta.isVisible()) {
            
            Main.main.remove(Main.scelta);
            Main.main.add(Main.opzioni);
            //validate e repaint servono per ridisegnare il contenuto del
            //frame
            Main.main.validate();
            Main.main.repaint();
            Main.opzioni.setVisible(true);
            Main.scelta.setVisible(false);
            
        }
    }
    
    public void nuovaPartitaActionPerformed(){
        
        if (Main.scelta.isVisible()) {
            
            Main.main.remove(Main.scelta);
            Main.main.add(Main.griglia);
            
            //validate e repaint servono per ridisegnare il contenuto del
            //frame
            Main.main.validate();
            Main.main.repaint();
            Main.griglia.setVisible(true);
            Main.scelta.setVisible(false);
            
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mousePressed(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
            
    }

    @Override
    public void mouseExited(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    }

