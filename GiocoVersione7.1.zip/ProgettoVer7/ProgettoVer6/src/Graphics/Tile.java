/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphics;

import SideClasses.Sprite;

/**
 *
 * @author xinxin
 */
public class Tile extends Sprite{
    //********** attributes *********
    //********** constructor ********
    public Tile(int posx, int posy, String tag, boolean solidity, boolean gravity){
        super(posx,posy,tag,solidity,gravity);
    }
    //*********** setting/getting ************
}
