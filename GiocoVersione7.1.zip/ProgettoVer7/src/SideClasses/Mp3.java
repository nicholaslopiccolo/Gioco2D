/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SideClasses;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 *
 * @author Famiglia
 */
public class Mp3 extends Thread{

   private Thread thread;
   private String nomeThread, nomeFile;
   private int start, stop;
   private boolean running = false;
   
   File audioFile;
   AudioInputStream audioStream;
   AudioFormat format;
   DataLine.Info info;
   Clip audioClip;
   
   public Mp3( String nomeThread, String nomeFile) {
      this.nomeThread = nomeThread;
      this.nomeFile = nomeFile;
      
      audioFile = new File(nomeFile); 
        
       try {
           audioStream = AudioSystem.getAudioInputStream(audioFile);
           format = audioStream.getFormat(); 
           info = new DataLine.Info(Clip.class, format);
           audioClip = (Clip) AudioSystem.getLine(info);
           audioClip.open(audioStream);
      } catch (UnsupportedAudioFileException ex) {
           Logger.getLogger(Mp3.class.getName()).log(Level.SEVERE, null, ex);
       } catch (IOException ex) {
           Logger.getLogger(Mp3.class.getName()).log(Level.SEVERE, null, ex);
       } catch (LineUnavailableException ex) {
           Logger.getLogger(Mp3.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
    
   @Override
    public synchronized void run() {
            running = true;
            audioClip.start();        
    }
    
    public boolean IsRunning(){return audioClip.isRunning();}
}