
package Controls;

import Model.GameManager;
import Model.Level;
import Model.MainApp;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashSet;
import java.util.Set;

public class ActionControl implements KeyListener{
    //*********** attributes *************
    private final Set<Character> pressed = new HashSet<Character>();
    @Override
    public void keyTyped(KeyEvent ke) {}
    @Override
    public void keyPressed(KeyEvent ke) {
        char action = ke.getKeyChar();
        pressed.add(action);
        if (pressed.contains('d') || pressed.contains('D')) Level.protagonist.moveRight();
        if (pressed.contains('a') || pressed.contains('A')) Level.protagonist.moveLeft();
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        pressed.remove(ke.getKeyChar());
    }
}
