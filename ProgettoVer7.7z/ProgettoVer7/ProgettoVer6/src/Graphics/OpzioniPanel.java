/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphics;

import Model.MainApp;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;

/**
 *
 * @author t.erra
 */
public class OpzioniPanel extends JPanel{
    public static ComandiPanel comandiPanel;
    
    Icon salvaIcon = new ImageIcon("src/Graphics/Images/GUI/nuovapartita.jpg");
    Icon salvaIconPressed = new ImageIcon("src/Graphics/Images/GUI/nuovapartita.jpg");
    Icon comandiIcon = new ImageIcon("src/Graphics/Images/GUI/continua.jpg");
    Icon indietroIcon = new ImageIcon("src/Graphics/Images/GUI/indietro.jpg");
    Icon indietroIconPressed = new ImageIcon("src/Graphics/Images/GUI/indietro2.jpg");
    Dimension d = new Dimension(190,49);
    Dimension s = new Dimension(480,450);
    
    JButton comandiButton;
    JButton indietro;
    JButton salvaPartita;
    
    public OpzioniPanel() {
        comandiPanel = new ComandiPanel();
        
        this.comandiButton = new JButton(comandiIcon); 
        this.salvaPartita = new JButton(salvaIcon);
        this.indietro = new JButton(indietroIcon);
      
        this.add(comandiButton);
        this.add(salvaPartita);
        this.add(indietro);
      
        comandiButton.setPreferredSize(d);
        salvaPartita.setPreferredSize(d);
        indietro.setPreferredSize(d);
    
        this.setOpaque(false);
        this.setPreferredSize(s);
        //-------- listener components
        indietro.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                indietroActionPerformed();
            }
        });
        
        comandiButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                comandiActionPerformed();
            }
        });
        
        indietro.addMouseListener(new MouseListener(){
            @Override
            public void mouseClicked(MouseEvent me) {}
            @Override
            public void mousePressed(MouseEvent me) {
                indietro.setIcon(indietroIconPressed);
            }
            @Override
            public void mouseReleased(MouseEvent me) {
                indietro.setIcon(indietroIcon);
            }
            @Override
            public void mouseEntered(MouseEvent me) {}
            @Override
            public void mouseExited(MouseEvent me) {}
        });
    }
    
    public void indietroActionPerformed(){ 
         MainApp.gameWindow.remove(this);
         MainApp.gameWindow.add(MainApp.gameWindow.sceltaPanel);
         //validate e repaint servono per ridisegnare il contenuto del
         //frame
         MainApp.gameWindow.validate();
         MainApp.gameWindow.repaint();
         MainApp.gameWindow.sceltaPanel.setVisible(true);
         MainApp.gameWindow.opzioniPanel.setVisible(false);
    }
    
    public void comandiActionPerformed(){
         MainApp.gameWindow.remove(this);
         MainApp.gameWindow.add(OpzioniPanel.comandiPanel);
         //validate e repaint servono per ridisegnare il contenuto del
         //frame
         MainApp.gameWindow.validate();
         MainApp.gameWindow.repaint();
    }
    
}
