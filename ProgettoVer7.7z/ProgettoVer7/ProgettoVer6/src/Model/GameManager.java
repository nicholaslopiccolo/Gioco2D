package Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author x.ruan
 */
public class GameManager extends Thread{
    //------------ fps -------------
    private int TARGET_FPS = 60;
    private double OPTIMAL_TIME = 1000000000 / TARGET_FPS;
    private double accumulatedTime = 0;
    private double lastLoopTime = System.nanoTime();
    //---------- game stats ----------
    public static Level level;
    private boolean InGame;
    //********* constructor ***********
    public GameManager(){
        InGame = false;
    }
    //********* setting/getting *********
    public double getCurrentTime(){return accumulatedTime;}
    public double getOPTIMAL_TIME(){return OPTIMAL_TIME;}
    public boolean InGame(){return InGame;}
    //********** operators ****************
    public void Update(){
        MainApp.gamePanel.repaint();
        Level.protagonist.Update();
    }
    public void startGame(){
        level = new Level(1);
        InGame = true;
        //iniziare la collisione
        while(InGame){
            double now = System.nanoTime();
            double updateLength = now - lastLoopTime;
            lastLoopTime = now;
            // update the frame counter
            accumulatedTime += updateLength;
            //Each frame
            if (accumulatedTime >= OPTIMAL_TIME) {
		accumulatedTime = 0;
                Update();
	    }
        }
    }
    @Override
    public void run(){
        startGame();
    }
    
}
