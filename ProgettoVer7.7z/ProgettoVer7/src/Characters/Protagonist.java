package Characters;

import Model.Level;
import SideClasses.Mp3;
import SideClasses.Sprite;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Protagonist extends Sprite{
    //********** attributes ***********
    //-------- animation speed
    final int TARGET_FPS = 12;
    private double OPTIMAL_TIME = 1000000000 / TARGET_FPS;
    private double accumulatedTime = 0;
    private double lastTime = System.nanoTime();
    //------- initialise frame size of animations
    private int MOVERIGHT_SIZE = 3;
    private int MOVELEFT_SIZE = 5;
    private int JUMP_SIZE = 5;
    private int ATTACK_SIZE = 5;
    //---- animations
    private BufferedImage[] Standby;
    private BufferedImage[] moveRight, moveLeft;
    private BufferedImage[] Jump;
    private BufferedImage[] Attack;
    private int frameCounter = 0;
    //----- properties
    private int Health;
    private int movementSpeed;
    //------ sounds
    private final Mp3 MovingMp3 = new Mp3("Thtread sparo", "src/Effetti Sonori/passi_scarpe_cuoio_su_legno.wav");
    
    //********** constructor ************
    public Protagonist(int posx, int posy, int width, int height, String tag, boolean solidity, boolean gravity, int health){
        super(posx, posy, width, height, tag,solidity,gravity);
        //----- initialise attributes
        moveRight = new BufferedImage[MOVERIGHT_SIZE];
        moveLeft = new BufferedImage[MOVELEFT_SIZE];
        Jump = new BufferedImage[JUMP_SIZE];
        Attack = new BufferedImage[ATTACK_SIZE];
        
        loadFrames();//load animation frames
        //----- initialise properties
        setHealth(health);
        currentFrame = moveRight[0];
    }
    
    public void validate(){
    }
    //********** setting/getting ***********
    public void setHealth(int h){this.Health = h;}
    //********** operators *********
    private final void loadFrames(){
        //!!!non avendo ancora le animazioni, questa parte lo facciamo dopo!!!
        try{
             for (int i = 0; i < moveRight.length; i++){
                moveRight[i] = ImageIO.read(getClass().getResource("../Graphics/Images/Protagonist/moveRight/" + Integer.toString(i) + ".png"));
             }  
        }catch(Exception ex){}

    }
    //********** operators ***********
    public void refreshFrame(){frameCounter = 0;}
    
    public void Update(){
        super.Update();
        double now = System.nanoTime();
        double updateLength = now - lastTime;
        lastTime = now;
        // update the frame counter
        accumulatedTime += updateLength;
        DoGravity();
        checkCollision();
    }
    public void moveRight(){
        if (frameCounter >= moveRight.length) frameCounter = 0;
        //----- when change action, reset frame count
        if (!currentAction.equals("moveRight")){
            frameCounter = 0;
            currentAction = "moveRight";
        }
        if (accumulatedTime >= OPTIMAL_TIME) {
            currentFrame = moveRight[frameCounter];
            PosX += 6;
            frameCounter++;
            accumulatedTime = 0;
            if (!MovingMp3.IsRunning()) MovingMp3.start();
        }
    }
    public void moveLeft(){
        if (frameCounter >= moveLeft.length) frameCounter = 0;
        //----- when change action, reset frame count
        if (!currentAction.equals("moveLeft")){
            frameCounter = 0;
            currentAction = "moveLeft";
        }
        if (accumulatedTime > OPTIMAL_TIME){
            currentFrame = moveLeft[frameCounter];
            PosX -= 6;
            frameCounter++;
            accumulatedTime = 0;
            if (!MovingMp3.IsRunning()) MovingMp3.start();
        }
    }
    public void Jump(){
        if (frameCounter >= Jump.length) frameCounter = 0;
        currentFrame = Jump[frameCounter];
        frameCounter++;
        if (accumulatedTime >= OPTIMAL_TIME) {
            currentFrame = Jump[frameCounter];
        }
    }
    public void Attack(){
        if (frameCounter >= Attack.length) frameCounter = 0;
        currentFrame = Attack[frameCounter];
        frameCounter++;
        
        Mp3 musica = new Mp3("Thtread sparo", "src/Effetti Sonori/passi_scarpe_cuoio_su_legno.wav");
        musica.start();
    }
    
    private void DoGravity(){
        boolean collided = false;
        if (Gravity){
            for (int i = 0; i < Level.TILE_SIZE; i++){
                if (getBottomBound().intersects(Level.tiles[i].getTopBound())) collided = true;
            }
            if (!collided) PosY += 2;
        }
    }
    
    private void checkCollision(){
        if (IsSolid){
            for (int i = 0; i < Level.TILE_SIZE; i++){
                if (getBound().intersects(Level.tiles[i].getLeftBound())) 
                    PosX -= (Math.abs(PosX + Width - Level.tiles[i].getPositionX()));
                if (getBound().intersects(Level.tiles[i].getRightBound()))
                    PosX += (Math.abs(PosX - Level.tiles[i].getWidth()));
            }
        }
    }
}
