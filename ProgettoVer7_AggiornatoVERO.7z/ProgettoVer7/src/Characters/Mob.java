
package Characters;

public class Mob {
    
}
