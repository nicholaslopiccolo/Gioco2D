package Characters;

import Model.Level;
import SideClasses.Ammo;
import SideClasses.JumpThread;
import SideClasses.Mp3;
import SideClasses.Sprite;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class Protagonist extends Sprite{
    //********** attributes ***********
    //-------- animation speed
    final int TARGET_FPS = 12;
    private double ANIMATION_TICKTIME = 1000000000 / TARGET_FPS;
    private double JUMP_FRAME = 1000000000 / 60;
    private double accumulatedTime = 0;
    private double lastTime = System.nanoTime();
    
    //------- initialise frame size of animations
    private int MOVERIGHT_SIZE = 3;
    private int MOVELEFT_SIZE = 5;
    private int JUMP_SIZE = 5;
    private int ATTACK_SIZE = 5;
    private double ATTACK_COOLDOWN = 1.5;
    private int AMMO_SIZE = 6;
    //---- animations
    private BufferedImage[] Standby;
    private BufferedImage[] moveRight, moveLeft;
    private BufferedImage[] Jump;
    private BufferedImage[] Attack;
    private int frameCounter = 0;
    private JumpThread jumpThread;
    
    //----- properties
    private double currentCooldown = 0;
    private char direction = 'r';
    private boolean IsAtGround = false;
    private int Health;
    private int movementSpeed;
    private ArrayList<Ammo> ammoAttack;
    private int ammoCounter = 0;
    //------ sounds
    private final Mp3 MovingMp3 = new Mp3("moving", "src/Effetti Sonori/passi_scarpe_cuoio_su_legno.wav");
    private final Mp3 JumpMp3 = new Mp3("jump","src/Effetti Sonori/sparo.wav");
    
    //********** constructor ************
    public Protagonist(int posx, int posy, int width, int height, String tag, boolean solidity, boolean gravity, int health){
        super(posx, posy, width, height, tag,solidity,gravity);
        //----- initialise attributes
        moveRight = new BufferedImage[MOVERIGHT_SIZE];
        moveLeft = new BufferedImage[MOVELEFT_SIZE];
        Jump = new BufferedImage[JUMP_SIZE];
        Attack = new BufferedImage[ATTACK_SIZE];
        
        loadFrames();//load animation frames
        //----- initialise properties
        setHealth(health);
        currentFrame = moveRight[0];
        movementSpeed = 5;
        jumpThread = new JumpThread(this);
        ammoAttack = new ArrayList();
    }
    
    public void validate(){
    }
    //********** setting/getting ***********
    public void removeAmmo(Ammo a){ammoAttack.remove(a);}
    public ArrayList<Ammo> getAmmoAttacks(){return this.ammoAttack;}
    public void setHealth(int h){this.Health = h;}
    public boolean IsAtGround(){return this.IsAtGround;}
    public int getAmmoCounter(){return this.ammoCounter;}
    public void setAmmoCounter(int a){this.ammoCounter = a;}
    
    //********** operators *********
    private final void loadFrames(){
        //!!!non avendo ancora le animazioni, questa parte lo facciamo dopo!!!
        try{
             for (int i = 0; i < moveRight.length; i++){
                moveRight[i] = ImageIO.read(getClass().getResource("../Graphics/Images/Protagonist/moveRight/" + Integer.toString(i) + ".png"));
             }  
        }catch(Exception ex){}

    }
    //********** operators ***********
    public void refreshFrame(){frameCounter = 0;}
    
    public void Update(){
        super.Update();
        double now = System.nanoTime();
        double updateLength = now - lastTime;
        lastTime = now;
        // update the frame counter
        accumulatedTime += updateLength;
        DoGravity();
        checkCollision();
    }
    public void moveRight(){
        if (frameCounter >= moveRight.length) frameCounter = 0;
        //----- when change action, reset frame count
        if (!currentAction.contains("moveRight")){
            frameCounter = 0;
            currentAction.add("moveRight");  
        }
        if (accumulatedTime >= ANIMATION_TICKTIME && !currentAction.contains("jumping")) {
            direction = 'R';
            currentFrame = moveRight[frameCounter];
            PosX += movementSpeed;
            frameCounter++;
            accumulatedTime = 0;
//            MovingMp3.start();
        }
    }
    public void moveLeft(){
        if (frameCounter >= moveLeft.length) frameCounter = 0;
        //----- when change action, reset frame count
        if (!currentAction.contains("moveLeft")){
            frameCounter = 0;
            currentAction.add("moveLeft");
        }
        if (accumulatedTime > ANIMATION_TICKTIME && !currentAction.contains("jumping")){
            direction = 'L';
            currentFrame = moveLeft[frameCounter];
            PosX -= movementSpeed;
            frameCounter++;
            accumulatedTime = 0;
//            MovingMp3.start();
        }
    }
    public void Jump(){
        if (!currentAction.contains("jumping") && !jumpThread.isAlive() && IsAtGround){
            currentAction.add("jumping");
//            JumpMp3.start();
            jumpThread.start();
        }
    }
    public void Attack(){
        currentAction.clear();
        frameCounter = 0;
 
        ammoAttack.add(new Ammo(PosX,PosY,direction));
        ammoAttack.get(ammoCounter).start();
        ammoCounter++;
//        Mp3 musica = new Mp3("Thread sparo", "src/Effetti Sonori/passi_scarpe_cuoio_su_legno.wav");
//        musica.start();
    }

    private void DoGravity(){
        IsAtGround = false;
        if (Gravity){
            for (int i = 0; i < Level.TILE_SIZE; i++){
                if (getBottomBound().intersects(Level.tiles[i].getTopBound())) IsAtGround = true;
            }
            if (!IsAtGround) PosY += 2;
        }
    }
    
    private void checkCollision(){
        if (IsSolid){
            for (int i = 0; i < Level.TILE_SIZE; i++){
                if (getBound().intersects(Level.tiles[i].getLeftBound())) 
                    PosX -= (Math.abs(PosX + Width - Level.tiles[i].getPositionX()));
                if (getBound().intersects(Level.tiles[i].getRightBound()))
                    PosX += (Math.abs(PosX - Level.tiles[i].getWidth()));
            }
        }
    }
}
