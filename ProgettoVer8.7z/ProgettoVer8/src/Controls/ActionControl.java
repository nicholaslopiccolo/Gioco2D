
package Controls;

import Model.Level;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashSet;
import java.util.Set;

public class ActionControl implements KeyListener{
    //*********** attributes *************
    private final Set<Character> pressed = new HashSet<Character>();
    @Override
    public void keyTyped(KeyEvent ke) {}
    @Override
    public void keyPressed(KeyEvent ke) {
         char action = ke.getKeyChar();
         if (!pressed.contains(action)) pressed.add(action);
         
         if (pressed.contains('d') || pressed.contains('D')) Level.protagonist.moveRight();
         if (pressed.contains('a') || pressed.contains('A')) Level.protagonist.moveLeft();
         if (pressed.contains('w') || pressed.contains('W')) Level.protagonist.Jump();
         if (pressed.contains('x')) Level.protagonist.Attack();
    }
    
    @Override
    public void keyReleased(KeyEvent ke) {
        char action = ke.getKeyChar();
        switch(action){
            case 'd':case 'D':{
                Level.protagonist.removeAction("moveRight");
                pressed.remove('d');
                break;
            }
            case 'a':case 'A':{
                Level.protagonist.removeAction("moveLeft");
                pressed.remove('a');
                break;
            }
            case 'w':case 'W':{
                pressed.remove('w');
                break;
            }
            case 'x':case 'X':{
                pressed.remove('x');
                break;
            }
        }
    }
    public Set<Character> getKeys(){return pressed;}
}
