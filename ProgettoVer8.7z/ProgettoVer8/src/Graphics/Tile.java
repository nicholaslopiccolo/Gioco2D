/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphics;

import SideClasses.Sprite;
import java.awt.image.BufferedImage;

/**
 *
 * @author xinxin
 */
public class Tile extends Sprite{
    //********** attributes *********
    private int ANIMATION_SIZE;
    BufferedImage[] animatedTile;
    //********** constructor ********
    public Tile(int posx, int posy, int width, int height, String tag, boolean solidity, boolean gravity){
        super(posx,posy, width, height, tag,solidity,gravity);
    }
    public Tile(int posx, int posy, int width, int height, String tag, boolean solidity, boolean gravity, BufferedImage[] animation){
        super(posx,posy, width, height, tag,solidity,gravity);
        animatedTile = animation;
    }
    //*********** setting/getting ************
    public void runAnimation(){
        super.runAnimation(animatedTile, true);
    }
}
