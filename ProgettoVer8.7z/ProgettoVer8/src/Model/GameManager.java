package Model;

import SideClasses.Ammo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author x.ruan
 */
public class GameManager extends Thread{
    //------------ fps -------------
    private static int TARGET_FPS = 80;
    public static double OPTIMAL_TIME = 1000000000 / TARGET_FPS;
    private double accumulatedTime = 0;
    private double lastLoopTime = System.nanoTime();
    public static double LastUpdateLength = 0;
    //---------- game stats ----------
    public static Level level;
    private boolean InGame;
    //********* constructor ***********
    public GameManager(){
        InGame = false;
    }
    //********* setting/getting *********
    public boolean InGame(){return InGame;}
    public void setInGame(boolean g){this.InGame = g;}
    public void loadScene(int l){level.setCurrentScene(l);}
    public int getCurrentScene(){return level.getCurrentScene();}
    //********** operators ****************
    public void Update(){
        MainApp.gamePanel.repaint();
        Level.protagonist.Update();
        for (Ammo ammo : Level.protagonist.getAmmoAttacks()){
            if (ammo != null) ammo.Update();
        }
    }
    public void startGame(){
        level = new Level(1);
        level.protagonist.validate();
        InGame = true;
        //iniziare la collisione
        while(InGame){
            double now = System.nanoTime();
            double updateLength = now - lastLoopTime;
            lastLoopTime = now;
            LastUpdateLength = updateLength;
            // update the frame counter
            accumulatedTime += updateLength;
            //Each frame
            if (accumulatedTime >= OPTIMAL_TIME) {
                Update();
                accumulatedTime = 0;
	    }
        }
    }
    @Override
    public void run(){
        startGame();
    }
   
    
}
