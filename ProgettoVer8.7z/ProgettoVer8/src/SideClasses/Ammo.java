/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SideClasses;

import Model.Level;
import Model.MainApp;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

/**
 *
 * @author xinxin
 */
public class Ammo{
    //********* attributes **********
    private int ID = 0;
    //-------- animation speed
    final int TARGET_FPS = 30;
    private double ANIMATION_TICKTIME = 1000000000 / TARGET_FPS;
    private double accumulatedTime = 0;
    private double lastLoopTime = System.nanoTime();
    private int frameCounter = 0;
    //-------- frames
    private Graphics2D g2d;
    private BufferedImage currentFrame;
    private BufferedImage[] axe;
    //---------- properties
    private boolean IsSolid = true;
    private int PosX, PosY;
    private int ANIMATION_SIZE = 9;
    private int Height = 40, Width = 40;
    private Rectangle Bound;
    private int Speed = 8;
    //********** constructor ************
    public Ammo(int posx, int posy, char direction, int id){
        //------- initialising
        ID = id;
        if (direction == 'L') Speed *= -1;
        PosX = posx;
        PosY = posy;
        axe = new BufferedImage[ANIMATION_SIZE];
        //------ load frames
        try{
            for (int i = 0; i < ANIMATION_SIZE; i++){
               axe[i] = ImageIO.read(getClass().getResource("../Graphics/Images/Protagonist/ammo/" + Integer.toString(i) + ".png"));
            }
        }catch(Exception ex){}
        Bound = new Rectangle(posx,posy,Width,Height);
        currentFrame = axe[0];
    }
    //******** setting/getting *************
    public BufferedImage getCurrentFrame(){return this.currentFrame;}
    public int getPositionX(){return this.PosX;}
    public int getPositionY(){return this.PosY;}
    public Rectangle getBound(){return new Rectangle(PosX,PosY, Width,Height);}
    public int getId(){return ID;}
    //******** operator ***********
    public void Update(){
        //--------- time calculation
        double now = System.nanoTime();
        double updateLength = now - lastLoopTime;
        lastLoopTime = now;
        accumulatedTime += updateLength;
        //---------- rendering
        if (IsSolid) MainApp.gamePanel.draw(currentFrame, PosX,PosY,MainApp.gamePanel);

        if (accumulatedTime > ANIMATION_TICKTIME){
            currentFrame = axe[frameCounter];
            PosX += Speed;
            frameCounter++;
            accumulatedTime = 0;
            if (frameCounter >= ANIMATION_SIZE) frameCounter = 0;
        }
        //---------- control
        if (checkCollision()) {
            IsSolid = false;
            Level.protagonist.removeAmmo(ID);
        }
    }
        
    private synchronized boolean checkCollision(){
        for (int i = 0; i < Level.TILE_SIZE; i++){
            if (getBound().intersects(Level.tiles[i].getBound())) return true;
        }
        if (PosX < 5 || PosX > MainApp.gamePanel.getWidth() - 50) return true;
        return false;
    }
}
