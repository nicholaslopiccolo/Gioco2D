/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SideClasses;

import Characters.Protagonist;

/**
 *
 * @author l.clemente
 */
public class JumpThread extends Thread{
    private Protagonist ref_protagonist;
    private boolean IsRunning = false;
    //*********** constructor *************
    public JumpThread(Protagonist protagonist){
        ref_protagonist = protagonist;
    }
    
    @Override
    public void start(){
        if (!IsRunning){
            IsRunning = true;
            this.run();
        }
    }
    @Override
    public synchronized void run(){
        int i = 0;
        //------- jumping up
        while(i < 40){
            ref_protagonist.setPositionY(ref_protagonist.getPositionY()-1);
            i++;
            if (ref_protagonist.getCurrentAction().contains("moveRight")) {
               ref_protagonist.setPositionX(ref_protagonist.getPositionX()+1);
            }
            else if (ref_protagonist.getCurrentAction().contains("moveLeft")) {
               ref_protagonist.setPositionX(ref_protagonist.getPositionX()-1);
            }
        }
        //------- jumping down
        while(!ref_protagonist.IsAtGround()){}
        ref_protagonist.getCurrentAction().remove("jumping");
        IsRunning = false;
    }
}
