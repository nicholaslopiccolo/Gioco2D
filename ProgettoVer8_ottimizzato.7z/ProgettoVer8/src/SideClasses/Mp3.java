/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SideClasses;

import java.io.File;
import javax.sound.sampled.*;

/**
 *
 * @author Famiglia
 */
public class Mp3 extends Thread{

   private Thread thread;
   private String nomeThread, nomeFile;
   private int start, stop;
   private boolean playCompleted = false;
   private boolean IsRunning = false;
   private File audioFile;
   private AudioInputStream audioStream;
   private AudioFormat format;
   private DataLine.Info info;
   private Clip audioClip;
   
   public Mp3( String nomeThread, String nomeFile) {
      this.nomeThread = nomeThread;
      this.nomeFile = nomeFile;
      audioFile = new File(nomeFile); 
       try {
           audioStream = AudioSystem.getAudioInputStream(audioFile);
           format = audioStream.getFormat(); 
           info = new DataLine.Info(Clip.class, format);
           audioClip = (Clip) AudioSystem.getLine(info);
           audioClip.open(audioStream);
        } catch (Exception ex) {}
   }
   @Override
    public synchronized void run() {
        IsRunning = true;
        audioClip.start();
    }
}