/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphics;

import Model.MainApp;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;

/**
 *
 * @author t.erra
 */
public class SceltaPanel extends JPanel{
    //******** attributes ********
    //------ images
    Icon nuovaPartitaIcon = new ImageIcon("src/Graphics/Images/GUI/nuovapartita.jpg");
    Icon nuovaPartitaIconPressed = new ImageIcon("src/Graphics/Images/GUI/nuovapartita2.jpg");
    Icon continuapartitaIcon = new ImageIcon("src/Graphics/Images/GUI/continua.jpg");
    Icon continuapartitaIconPressed = new ImageIcon("src/Graphics/Images/GUI/continua2.jpg");
    Icon opzioniIcon = new ImageIcon("src/Graphics/Images/GUI/opzioni.jpg");
    Icon opzioniIconPressed = new ImageIcon("src/Graphics/Images/GUI/opzioni2.jpg");
    //------------ components
    Dimension d = new Dimension(190,49);
    Dimension s = new Dimension(480,450);
    JButton nuovaPartita;
    JButton caricaPartita;
    JButton opzioni;
    //************** constructor *******************
    public SceltaPanel()  {
         //----- initializza bottoni
         this.nuovaPartita = new JButton (nuovaPartitaIcon);
         this.caricaPartita = new JButton (continuapartitaIcon);
         this.opzioni = new JButton (opzioniIcon);
         //----- aggiungi i bottoni
         this.add(nuovaPartita);
         this.add(caricaPartita);
         this.add(opzioni);
         //------- dimensione bottone
         nuovaPartita.setPreferredSize(d);
         caricaPartita.setPreferredSize(d);
         opzioni.setPreferredSize(d);
         //----- set property
         this.setOpaque(false);
         this.setPreferredSize(s);
    
         //-------- add listener
         opzioni.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
               opzioniActionPerformed();
            }
         });
    
         nuovaPartita.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
               nuovaPartitaActionPerformed();
            }
         });
    
         nuovaPartita.addMouseListener(new MouseListener(){
            @Override
            public void mouseClicked(MouseEvent me) {}
            @Override
            public void mousePressed(MouseEvent me) {nuovaPartita.setIcon(nuovaPartitaIconPressed);}
            @Override
            public void mouseReleased(MouseEvent me) {nuovaPartita.setIcon(nuovaPartitaIcon);}
            @Override
            public void mouseEntered(MouseEvent me) {}
            @Override
            public void mouseExited(MouseEvent me) {}
        });
         
        opzioni.addMouseListener(new MouseListener(){
            @Override
            public void mouseClicked(MouseEvent me) {}
            @Override
            public void mousePressed(MouseEvent me) {opzioni.setIcon(opzioniIconPressed);}
            @Override
            public void mouseReleased(MouseEvent me) {opzioni.setIcon(opzioniIcon);}
            @Override
            public void mouseEntered(MouseEvent me) {}
            @Override
            public void mouseExited(MouseEvent me) {}
        });
        
        caricaPartita.addMouseListener(new MouseListener(){
            @Override
            public void mouseClicked(MouseEvent me) {}
            @Override
            public void mousePressed(MouseEvent me) {caricaPartita.setIcon(continuapartitaIconPressed);}
            @Override
            public void mouseReleased(MouseEvent me) {caricaPartita.setIcon(continuapartitaIcon);}
            @Override
            public void mouseEntered(MouseEvent me) {}
            @Override
            public void mouseExited(MouseEvent me) {}
        });
    
    }
    //************** operators **************
    private void opzioniActionPerformed(){
           MainApp.gameWindow.remove(this);
           MainApp.gameWindow.add(MainApp.gameWindow.opzioniPanel);
           //validate e repaint servono per ridisegnare il contenuto del
           //frame
           MainApp.gameWindow.validate();
           MainApp.gameWindow.opzioniPanel.setVisible(true);
           MainApp.gameWindow.repaint();
    }
    
    private void nuovaPartitaActionPerformed(){
        //------- setup window
        MainApp.gameWindow.remove(this);
        MainApp.gameWindow.removeSfondo();
        MainApp.gameWindow.add(MainApp.gamePanel);
        MainApp.gameWindow.validate();
        MainApp.gameWindow.pack();
        MainApp.gameWindow.repaint();
        //------ start the game
        MainApp.gameManager.start();
    }
}

