
package Characters;

import Model.Level;
import SideClasses.Ammo;
import SideClasses.Sprite;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Mob extends Sprite {
    
    final int TARGET_FPS = 12;
    private double ANIMATION_TICKTIME = 1000000000 / TARGET_FPS;
    
    private double accumulatedTime = 0;
    private double lastTime = System.nanoTime();
    
    private int MOVERIGHT_SIZE = 5;
    private int MOVELEFT_SIZE = 5;
    private int AMMO_SIZE = 10;
    
    private int ATTACK_SIZE = 5;
    private double ATTACK_COOLDOWN = 1000000000 / 2;
    
    private BufferedImage[] Standby;
    private BufferedImage[] moveRight, moveLeft;
    private BufferedImage[] Attack;
    private int frameCounter = 0;
    
    private double currentCooldown = 0;
    private char direction = 'r';
    private boolean IsAtGround = false;
    private int lastPositionY = 0;
    
    private int Health;
    private int movementSpeed;
    private Ammo[] ammoAttack;
    private int ammoCounter = 0;
    
    public Mob (int posx, int posy, int width, int height, String tag, boolean solidity, boolean gravity, int health){
        super(posx, posy, width, height, tag,solidity,gravity);
        //----- initialise attributes
        moveRight = new BufferedImage[MOVERIGHT_SIZE];
        moveLeft = new BufferedImage[MOVELEFT_SIZE];
        Attack = new BufferedImage[ATTACK_SIZE];
        ammoAttack = new Ammo[AMMO_SIZE];
        
        loadFrames();
        
        setHealth(health);
        
    }
    
    public Ammo[] getAmmoAttacks(){return this.ammoAttack;}
    public void setHealth(int h){this.Health = h;}
    public boolean IsAtGround(){return this.IsAtGround;}
    public int getAmmoCounter(){return this.ammoCounter;}
    public void setAmmoCounter(int a){this.ammoCounter = a;}
    public void setGround(boolean g){this.IsAtGround = g;}
    
    private void checkCollision(){
        if (IsSolid){
            for (int i = 0; i < Level.TILE_SIZE; i++){
                if (getRightBound().intersects(Level.tiles[i].getBound())){
                    //difference between right bound's position and tiles' left bound's position
                    PosX -= (Math.abs(PosX + Width - Level.tiles[i].getPositionX()));
                }
                if (getLeftBound().intersects(Level.tiles[i].getBound())){
                     //difference between left bound's position and tiles' right bound's position
                    PosX += (Math.abs(Level.tiles[i].getPositionX() + Level.tiles[i].getWidth() - PosX));
                }
            }
        }
    }
    
    private void doGravity(){
        boolean collided = false;
        if (Gravity){
            PosY += 3;
            for(int i = 0; i < Level.TILE_SIZE; i++){
                if (getBottomBound().intersects(Level.tiles[i].getBound())) {
                    //set protagonist's position Y up at tiles's top bound
                    PosY = Level.tiles[i].getPositionY() - Height;
                    collided = true;
                }
            }
        }
        IsAtGround = collided;
    }
    
    public void Attack(){
        //------ do attack only if cooldown has satisfied
        if (currentCooldown >= ATTACK_COOLDOWN){
            currentAction.clear();
            currentCooldown = 0;
            frameCounter = 0;
            //---- find the "null ammo" and make it a solid new ammo
            for (int i = 0; i < AMMO_SIZE; i++){
                if (ammoAttack[i] == null) {
                    ammoAttack[i] = new Ammo(PosX,PosY,direction,i);
                    i = AMMO_SIZE;
                }
            }
        }
    }
    
    @Override
    public void Update(){
        super.Update();
        double now = System.nanoTime();
        double updateLength = now - lastTime;
        lastTime = now;
        // update the frame counter
        currentCooldown += updateLength;
        accumulatedTime += updateLength;
        doGravity();
        checkCollision();
    }
    
    public void refreshFrame(){frameCounter = 0;}
    
    private final void loadFrames(){
        //!!!non avendo ancora le animazioni, questa parte lo facciamo dopo!!!
        try{
             for (int i = 0; i < moveRight.length; i++){
                moveRight[i] = ImageIO.read(getClass().getResource("../Graphics/Images/MobRight/" + Integer.toString(i) + ".png"));
             }  
        }catch(IOException ex){}
        setCurrentFrame(moveRight[0]);
    }
    
}
