/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphics;

import Model.MainApp;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;
/**
 *
 * @author x.ruan
 */
public class ComandiPanel extends JPanel {
    //******** attributes *******
    private JLabel sfondo;
    private JButton indietro;
    private Icon sfondoIcon = new ImageIcon("src/Graphics/Images/Background/menuComandi.jpg");
    private Icon indietroIcon = new ImageIcon("src/Graphics/Images/GUI/indietro.jpg");
    private Icon indietroIconPressed = new ImageIcon("src/Graphics/Images/GUI/indietro2.jpg");
    //***** constructor *****
    public ComandiPanel(){
        //---------- set panel properties
        this.setPreferredSize(new Dimension(480,450));
        this.setLayout(new BorderLayout());
        this.setOpaque(false);
        //--------- initialise components
        sfondo = new JLabel(sfondoIcon);
        indietro = new JButton(indietroIcon);
        
        //---------- set component properties
        sfondo.setPreferredSize(new Dimension(320,320));
        indietro.setPreferredSize(new Dimension(300,80));
        
        this.add(sfondo, BorderLayout.NORTH);
        this.add(indietro, BorderLayout.SOUTH);
        
        //--------- setup listeners
        indietro.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                indietroActionPerformed();
            }
        });
        indietro.addMouseListener(new MouseListener(){
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {
                indietro.setIcon(indietroIconPressed);
            }
            @Override
            public void mouseReleased(MouseEvent e) {
                indietro.setIcon(indietroIcon);
            }
            @Override
            public void mouseEntered(MouseEvent e) {}
            @Override
            public void mouseExited(MouseEvent e) {}
        });
    }
    
    public void indietroActionPerformed(){
        MainApp.gameWindow.remove(this);
        MainApp.gameWindow.add(MainApp.gameWindow.opzioniPanel);
        MainApp.gameWindow.validate();
        MainApp.gameWindow.repaint();
    }
}
