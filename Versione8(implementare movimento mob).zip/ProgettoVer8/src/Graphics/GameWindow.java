/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphics;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
/**
 *
 * @author xinxin
 */
public class GameWindow extends JFrame{

    protected static OpzioniPanel opzioniPanel;
    protected static SceltaPanel sceltaPanel;

    private JLabel sfondo;
    //************ constructor ***********
    public GameWindow(){
        //----- initializza components
        opzioniPanel = new OpzioniPanel();
        sceltaPanel = new SceltaPanel();
        
        BufferedImage img = null;
        try {
            img = ImageIO.read(getClass().getResource("Images/GUI/background.png"));
        } catch (IOException ex) {
            System.out.println("non carica");
        }
        sfondo = new JLabel(new ImageIcon(img));
        
        sfondo.setLayout(new GridBagLayout());
        sceltaPanel.setLayout(new GridLayout(3,1,50,100));
        opzioniPanel.setLayout(new GridLayout(3,1,50,100));
        
        GridBagConstraints gbc = new GridBagConstraints();
     
        gbc.gridwidth = GridBagConstraints.NORTH;
        gbc.fill = GridBagConstraints.CENTER;
        this.add(sfondo);
        sfondo.add(sceltaPanel);
        
        this.setSize(1024,512);
        this.setLocation(250,100);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    //*********** operators ************
    public void removeSfondo(){remove(sfondo);}
    public void showSfondo(){add(sfondo);}
    
    @Override
    public void remove(Component component){sfondo.remove(component);}

    public void add(OpzioniPanel op){sfondo.add(op);}
    public void add(SceltaPanel sp){sfondo.add(sp);}
    public void add(ComandiPanel cp){sfondo.add(cp);}
}
