
package Model;

import Graphics.GameWindow;
import Graphics.GrigliaPanel;


public class MainApp {
    public static GameWindow gameWindow;
    public static GameManager gameManager;
    //-------- GUI component
    public static GrigliaPanel gamePanel;
    
    public static void main(String[] args) {
        //****** initialise window ******
        //------- setup window
        gameManager = new GameManager();
        gameWindow = new GameWindow();
        gamePanel = new GrigliaPanel();
        //------- setup components
    }
}
