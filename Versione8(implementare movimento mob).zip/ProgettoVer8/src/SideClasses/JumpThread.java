/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SideClasses;

import Characters.Protagonist;
import Model.Level;

/**
 *
 * @author l.clemente
 */
public class JumpThread extends Thread{
    //********** constants
    private double DELAY_TIME = 10000000 / 20;
    
    private double accumulatedTime = 0;
    //******** attributes
    private Protagonist ref_protagonist;
    private boolean IsRunning = false;
    //*********** constructor *************
    public JumpThread(Protagonist protagonist){
        ref_protagonist = protagonist;
    }
    
    @Override
    public void start(){
        if (!IsRunning){
            IsRunning = true;
            run();
        }
    }
    @Override
    public synchronized void run(){
        //------- time initilise -------
        double lastTime = System.nanoTime();
        double now = System.nanoTime();
        double updateLength = 0;
        int i = 0;
        //------- jumping up
        while(i < 60){
            //----- calculate delay time
            now = System.nanoTime();
            updateLength = now - lastTime;
            accumulatedTime += updateLength;
            lastTime = now;
            //------ apply operations each delay time
            if (accumulatedTime > DELAY_TIME ){
                ref_protagonist.setPositionY(ref_protagonist.getPositionY()-1);
                i++;
                if (ref_protagonist.getCurrentAction().contains("moveRight")) {
                    ref_protagonist.setPositionX(ref_protagonist.getPositionX()+1);
                }
                else if (ref_protagonist.getCurrentAction().contains("moveLeft")) {
                    ref_protagonist.setPositionX(ref_protagonist.getPositionX()-1);
                }
                accumulatedTime = 0;
            }
        }
        ref_protagonist.getCurrentAction().remove("jumping");
        IsRunning = false;
    }
}
