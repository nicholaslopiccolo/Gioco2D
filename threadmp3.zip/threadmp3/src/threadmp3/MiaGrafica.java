package threadmp3;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import threadmp3.Mp3;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Famiglia
 */
public class MiaGrafica extends JPanel {
    
    
    JButton b;
    
    public MiaGrafica(){
    
        b = new JButton("Spara");
        this.add(b);
        b.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
                
                //permette di visualizzare il numero 1 all'interno della TextField risultato
                Mp3 musica = new Mp3("Thtread sparo", "C:/Users/Maurizio/Desktop/Effetti Sonori/sparo.wav");
                musica.start();
            } 
        });
    
        
    }
   
    
}
