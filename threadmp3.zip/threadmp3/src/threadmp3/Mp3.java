/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadmp3;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import sun.applet.Main;

/**
 *
 * @author Famiglia
 */
public class Mp3 extends Thread{

   private Thread thread;
   private String nomeThread, nomeFile;
   private int start, stop;
   
   File audioFile;
   AudioInputStream audioStream;
   AudioFormat format;
   DataLine.Info info;
   Clip audioClip;
   
   Mp3( String nomeThread, String nomeFile) {
      this.nomeThread = nomeThread;
      this.nomeFile = nomeFile;
      System.out.println(nomeThread + " creato.");
      
      audioFile = new File(nomeFile); 
        
       try {
           audioStream = AudioSystem.getAudioInputStream(audioFile);
           format = audioStream.getFormat(); 
           info = new DataLine.Info(Clip.class, format);
           audioClip = (Clip) AudioSystem.getLine(info);
            audioClip.open(audioStream);
      } catch (UnsupportedAudioFileException ex) {
           Logger.getLogger(Mp3.class.getName()).log(Level.SEVERE, null, ex);
       } catch (IOException ex) {
           Logger.getLogger(Mp3.class.getName()).log(Level.SEVERE, null, ex);
       } catch (LineUnavailableException ex) {
           Logger.getLogger(Mp3.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
    
    public void run() {
            audioClip.start();        
    }
    
    public void start () {
      System.out.println(nomeThread +" in esecuzione.");
      if (thread == null) {
         thread = new Thread (this, nomeThread);
         thread.start ();
      }
     
   }
}